unless defined?(RSpec)
  describe "Bar#baz" do
    it "works" do
      1.should == 1
    end
  end
end
