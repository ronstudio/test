require 'mspec/utils/version'

module MSpec
  VERSION = SpecVersion.new "1.8.0"
end
