require File.expand_path('../../../spec_helper', __FILE__)
require 'open3'

describe "Open3.pipeline" do
  it "needs to be reviewed for spec completeness"
end
